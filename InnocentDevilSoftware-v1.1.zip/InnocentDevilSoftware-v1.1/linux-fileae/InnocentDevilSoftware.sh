#!/bin/bash

echo "Hello"
echo "Welcome to InnocentDevil Software"
echo "Press any key to view the source code of this software"
read -n 1 -s -r
clear

# Matrix effect
while true; do
    echo $RANDOM$RANDOM$RANDOM$RANDOM$RANDOM$RANDOM$RANDOM$RANDOM$RANDOM$RANDOM$RANDOM$RANDOM$RANDOM$RANDOM$RANDOM$RANDOM$RANDOM$RANDOM$RANDOM$RANDOM
    sleep 0.1
done
