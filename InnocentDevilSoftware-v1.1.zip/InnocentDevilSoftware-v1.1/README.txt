Hello there! Thank you for installing Innocent Devil Software v1.1!

NOTICE:-

THIS APPLICATION DOES NOT MAKE ANY CHANGES OR INSTALL ANYTHING IN YOUR COMPUTER. IT IS JUST A FILE AND IT DOES NOT ASK FOR ANY PERMISSION NOR COLLECTS ANY OF YOUR INFO. MADE FOR FUN PURPOSES ONLY.



Supported OSs (for v1.1)

All Windows Versions

Linux





Open winfile folder for the file in Windows.
Open linux-fileae for the file in Linux


Steps for running the file in Windows:-
Extract the .zip file
Go to the winfile folder
Double click on InnocentDevilSoftware.bat
Voila!

Steps for running the file in Linux:-
Open Terminal
Navigate to Downloads (type 'cd Downloads' in terminal)
Unzip it by typing "unzip InnocentDevilSoftware.zip
Type "cd InnocentDevilSoftware"
Type "cd linux-fileae"
Type "chmod +x InnocentDevilSoftware.sh"
after that, type "./InnocentDevilSoftware.sh"
(if the last step doesnt work try running it with root by adding sudo before ./)

If you like this Software, be sure to give feedback on GitHub

